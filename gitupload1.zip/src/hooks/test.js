const m = {
  iss: "https://discord.com/api",
  sub: "1138373098433949726",
  name: "minaamirsammy#0",
  email: "minajuve11@gmail.com",
  hello: "world",
  picture: "https://cdn.discordapp.com/embed/avatars/0.png",
  full_name: "minaamirsammy",
  avatar_url: "https://cdn.discordapp.com/embed/avatars/0.png",
  oAuthToken: "BuylUdBOIkV4Z2mw3Q8ihjQ1Q3MSJK",
  provider_id: "1138373098433949726",
  custom_claims: { global_name: "minaamirsammy" },
  email_verified: true,
};
