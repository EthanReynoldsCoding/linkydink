import React from "react";

const LogoComponent = () => {
  return (
    <div>
      {/* Your beautiful logo here */}
      <h1>Pinkerton Chevrolet</h1>
    </div>
  );
};

export default LogoComponent;
