import React from "react";

const FooterComponent = () => {
  return (
    <div>
      {/* Your beautiful footer here */}
      <footer>
        <p>Strive for Innovation, Achieve Excellence</p>
      </footer>
    </div>
  );
};

export default FooterComponent;
