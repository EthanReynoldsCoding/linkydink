import { fetchSalesData } from './salesData'; // Adjust the path as needed

export const barChartDataDashboard = [
  {
    name: "Sales",
    data: [0, 0, 0, 0, 0, 0, 0, 12.5, 7, 0, 0, 0],
  },
];
