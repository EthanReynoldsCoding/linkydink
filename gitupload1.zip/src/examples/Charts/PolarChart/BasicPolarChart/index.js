import React from "react";
import ReactApexChart from "react-apexcharts";

class BasicPolarChart extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      chartData: [],
      chartOptions: {},
    };
  }

  componentDidMount() {
    this.setState({
      chartData: this.props.polarChartData,
      chartOptions: this.props.polarChartOptions,
    });
  }

  render() {
    return (
      <ReactApexChart
        options={this.state.chartOptions}
        series={this.state.chartData}
        type="polarArea"
        width="100%"
        height="100%"
      />
    );
  }
}

export default BasicPolarChart;